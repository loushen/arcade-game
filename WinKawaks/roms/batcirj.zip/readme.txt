These files are not ROM's in any way, they simply
allow encrypted ROM's to be non-encrypted.

eof